#include <stdio.h>
#include <stdbool.h>

void main() {
  int x = 5;

}