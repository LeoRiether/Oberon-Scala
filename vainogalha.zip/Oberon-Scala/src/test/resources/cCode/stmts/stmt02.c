#include <stdio.h>
#include <stdbool.h>

void main() {
  int x, y, z;

  scanf("%d", &x);
  scanf("%d", &y);
  z = x + y;
  printf("%d\n", z);
}