#include <stdio.h>
#include <stdbool.h>

void main() {
    int x, y;

    scanf("%d", &x);
    scanf("%d", &y);
    printf("%d\n", x + y);
}