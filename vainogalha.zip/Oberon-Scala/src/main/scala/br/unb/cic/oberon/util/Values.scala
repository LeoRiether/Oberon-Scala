package br.unb.cic.oberon.util

object Values {
  val ReturnKeyWord = "return"
}
